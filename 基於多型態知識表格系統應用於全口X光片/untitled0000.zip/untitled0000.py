import pandas as pd
import matplotlib.pyplot as plt
from adjustText import adjust_text

# 使用支持中文字符的字體
plt.rcParams['font.family'] = 'Microsoft YaHei'  # 將其更改為您喜歡的字體

# 讀取 Excel 檔案
excel_file_path = 'C:/Users/leo0818/Desktop/新專題/專題/KellyGrid.xlsx'  
df = pd.read_excel(excel_file_path, index_col=0)

def calculate_percentage(value):
    # 計算轉換為百分比
    percentage = 20 + (value - 1) * 20
    return percentage

def find_diagnosis(symptom):
    # 檢查症狀是否在第一欄
    if symptom in df.columns:
        # 找到對應分數的特徵
        features = df[df[symptom].notna()].index.tolist()

        # 逐一處理每個特徵
        results = []
        for feature in features:
            # 計算轉換為百分比
            value = df.at[feature, symptom]
            percentage = calculate_percentage(value)

            # 保存結果
            results.append((feature, percentage))

        # 按百分比降序排序
        results.sort(key=lambda x: x[1], reverse=True)

        # 只保留前兩個診斷
        top_diagnoses = results[:2]

        # 生成凱利方格推論圖
        plt.figure(figsize=(8, 6))
        
        # 調整 adjustText 库的範例
        texts = []

        for diagnosis, percentage in top_diagnoses:
            scatter = plt.scatter(df.at[diagnosis, symptom], percentage,  marker='o')
            texts.append(plt.text(df.at[diagnosis, symptom], percentage, f'{diagnosis}: {percentage:.0f}%', fontsize=8))

        # 添加所有症狀的點，避免重疊
        other_diagnoses = [feature for feature, _ in results[2:]]
        for feature in other_diagnoses:
            value = df.at[feature, symptom]
            percentage = calculate_percentage(value)
            scatter = plt.scatter(value, percentage, color='grey', alpha=0.5)
            texts.append(plt.text(value, percentage, f'{feature}: {percentage:.0f}%', fontsize=8))

        # 調整文字和點的位置，避免重疊
        adjust_text(texts, arrowprops=dict(arrowstyle='-', lw=0.5), force_text=3.5)  # 調整 force_text 的值

        plt.title(f'Kelly Grid Inference for {symptom}')
        plt.xlabel('Raw Score')
        plt.ylabel('Percentage')
        plt.grid(True)

        # 去掉左上方的文字敘述
        plt.annotate('', xy=(0, 0), xytext=(0, 0), textcoords='figure points', xycoords='figure points', alpha=0)

        plt.show()
    else:
        print(f'找不到症狀: {symptom}')

# 測試
user_symptom = input('請輸入症狀: ')
find_diagnosis(user_symptom)
